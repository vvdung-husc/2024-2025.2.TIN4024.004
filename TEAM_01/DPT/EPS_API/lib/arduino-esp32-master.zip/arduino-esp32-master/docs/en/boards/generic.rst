####################
Generic ESP32 Boards
####################

Specifications
--------------

Add here the board/kit specifications.

Header Block
------------

Header1
^^^^^^^

.. vale off

===  ====  =====  ===================================
No.  Name  Type   Function
===  ====  =====  ===================================
1    3V3   P      3.3 V power supply
2    IO0   I/O    GPIO0, Boot
3    5V0   P      5 V power supply
4    GND   G      Ground
===  ====  =====  ===================================

.. vale on

Pin Layout
----------

Add here the pin layout image (not required).

.. include:: ../common/datasheet.inc
